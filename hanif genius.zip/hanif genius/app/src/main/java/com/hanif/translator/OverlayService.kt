package com.hanif.translator

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.ContextThemeWrapper
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {
    private data class Item(val n: Int, val t: String)

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null

    private lateinit var bubbleRoot: LinearLayout
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var menu: LinearLayout
    private var panel: LinearLayout? = null
    private lateinit var panelLp: WindowManager.LayoutParams
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private var panelShown = false
    private var full = false
    private var sel: SelectionView? = null
    private var lastBox: RectF? = null
    private val results = ArrayList<Item>()
    private var counter = 0

    private fun lp(w: Int, hh: Int, flags: Int) =
        WindowManager.LayoutParams(w, hh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)
    private val NF = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (proj != null) return START_NOT_STICKY
        startFg()
        val data = readData(i)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(i!!.getIntExtra("code", 0), data)
        proj = p
        p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { h.post { stopSelf() } } }, h)
        val m = metrics()
        reader = ImageReader.newInstance(m.widthPixels, m.heightPixels, PixelFormat.RGBA_8888, 2)
        vd = p.createVirtualDisplay("scan", m.widthPixels, m.heightPixels, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, h)
        buildBubble()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java) else i?.getParcelableExtra<Intent>("data")

    @Suppress("DEPRECATION")
    private fun metrics(): DisplayMetrics {
        val m = DisplayMetrics()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return m
    }

    override fun onConfigurationChanged(c: android.content.res.Configuration) {
        super.onConfigurationChanged(c)
        val v = vd ?: return
        val m = metrics()
        reader?.close()
        reader = ImageReader.newInstance(m.widthPixels, m.heightPixels, PixelFormat.RGBA_8888, 2)
        v.resize(m.widthPixels, m.heightPixels, m.densityDpi)
        v.surface = reader!!.surface
    }

    @Suppress("DEPRECATION")
    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ov", getString(R.string.app_name), NotificationManager.IMPORTANCE_MIN))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "ov")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.running))
            .addAction(Notification.Action.Builder(0, getString(R.string.stop), stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------- Floating bubble + 3-button menu ----------
    private fun buildBubble() {
        val size = dp(40)
        val bubble = circleBtn("文A", C.GREEN) {}.apply { textSize = 12f }
        menu = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        fun mb(t: String, c: Int, f: () -> Unit) =
            menu.addView(circleBtn(t, c, f), LinearLayout.LayoutParams(size, size).apply { topMargin = dp(6) })
        mb("🔍", C.GREEN) { startScan() }
        mb("🌐", C.GRAY) { chooseLanguages() }
        mb("✖", C.RED) { closeOverlay() }

        bubbleRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bubble, LinearLayout.LayoutParams(size, size)); addView(menu)
        }
        bubbleLp = lp(WRAP, WRAP, NF).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = dp(200) }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                android.view.MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = bubbleLp.x; oy = bubbleLp.y; moved = false; true }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { bubbleLp.x = (ox + dx).toInt(); bubbleLp.y = (oy + dy).toInt(); wm.updateViewLayout(bubbleRoot, bubbleLp) }
                    true
                }
                android.view.MotionEvent.ACTION_UP -> { if (!moved) toggleMenu(); true }
                else -> false
            }
        }
        wm.addView(bubbleRoot, bubbleLp)
    }

    private fun toggleMenu() {
        if (menu.visibility == View.VISIBLE) menu.visibility = View.GONE
        else { menu.alpha = 0f; menu.visibility = View.VISIBLE; menu.animate().alpha(1f).setDuration(150).start() }
    }

    private fun closeOverlay() { menu.visibility = View.GONE; closeSel(); hidePanel() }

    // ---------- Scan ----------
    private fun startScan() {
        if (sel != null) return
        menu.visibility = View.GONE
        val m = metrics()
        val box = lastBox ?: RectF(m.widthPixels * 0.1f, m.heightPixels * 0.35f, m.widthPixels * 0.9f, m.heightPixels * 0.5f)
        val v = SelectionView(this, box, { r -> lastBox = RectF(r); runScan(r) }, { closeSel() })
        val p = lp(MATCH, MATCH, NF or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        if (Build.VERSION.SDK_INT >= 30) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else if (Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        sel = v; wm.addView(v, p)
    }

    private fun closeSel() { sel?.let { try { wm.removeView(it) } catch (e: Exception) {} }; sel = null }

    private fun runScan(r: RectF) {
        val v = sel ?: return
        val loc = IntArray(2); v.getLocationOnScreen(loc)
        val rect = Rect((r.left + loc[0]).toInt(), (r.top + loc[1]).toInt(), (r.right + loc[0]).toInt(), (r.bottom + loc[1]).toInt())
        closeSel()
        bubbleRoot.visibility = View.INVISIBLE; panel?.visibility = View.INVISIBLE
        h.postDelayed({ capture(rect) }, 300)
    }

    private fun restore() { bubbleRoot.visibility = View.VISIBLE; panel?.visibility = View.VISIBLE }

    private fun capture(rect: Rect) {
        val img = reader?.acquireLatestImage()
        if (img == null) { restore(); toast(getString(R.string.no_frame)); return }
        val bmp = try { toBitmap(img, rect) } finally { img.close() }
        restore()
        val src = Prefs.src(this); val dst = Prefs.dst(this)
        Engine.recognize(bmp, src) { txt ->
            bmp.recycle()
            if (txt.isNullOrBlank()) toast(getString(R.string.no_text))
            else Engine.translate(txt.trim(), src, dst) { out -> if (out == null) toast(getString(R.string.fail)) else addResult(out) }
        }
    }

    private fun toBitmap(img: Image, r: Rect): Bitmap {
        val p = img.planes[0]
        val full = Bitmap.createBitmap(p.rowStride / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(p.buffer)
        val x = r.left.coerceIn(0, img.width - 1); val y = r.top.coerceIn(0, img.height - 1)
        val w = (r.right - x).coerceIn(1, img.width - x); val hh = (r.bottom - y).coerceIn(1, img.height - y)
        val out = Bitmap.createBitmap(full, x, y, w, hh)
        if (out !== full) full.recycle()
        return out
    }

    // ---------- Bubble stack ----------
    private fun addResult(t: String) { results.add(Item(++counter, t)); showPanel(); render() }

    private fun showPanel() {
        if (panel == null) buildPanel()
        if (!panelShown) { wm.addView(panel!!, panelLp); panelShown = true }
    }
    private fun hidePanel() { if (panelShown) { wm.removeView(panel!!); panelShown = false } }

    private fun buildPanel() {
        val head = LinearLayout(this).apply { setPadding(dp(8), dp(6), dp(8), dp(6)) }
        fun hb(t: String, c: Int, f: () -> Unit) = head.addView(button(t, c, f),
            LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(6) })
        hb(getString(R.string.copy_all), C.GREEN) { copy(results.joinToString("\n\n") { it.t }) }
        hb(getString(R.string.reset), C.RED) { results.clear(); counter = 0; render() }
        hb("⛶", C.GRAY) { toggleFull() }
        hb("✖", C.GRAY) { hidePanel() }
        scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(8)) }
        scroll.addView(list)
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG)
            addView(head); addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        panelLp = lp(MATCH, (metrics().heightPixels * 0.4).toInt(), NF).apply { gravity = Gravity.BOTTOM }
    }

    private fun toggleFull() {
        full = !full
        panelLp.height = if (full) MATCH else (metrics().heightPixels * 0.4).toInt()
        wm.updateViewLayout(panel!!, panelLp)
    }

    private fun render() {
        list.removeAllViews()
        results.forEachIndexed { i, x -> list.addView(itemView(x, i == results.lastIndex),
            LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) }) }
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun itemView(x: Item, newest: Boolean): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8))
            background = shape(C.BG, 10, if (newest) C.GREEN else C.GRAY, if (newest) 2 else 1)
        }
        val row = LinearLayout(this)
        row.addView(label("#${x.n}", 12f, C.GRAY), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(label(getString(R.string.copy), 13f, C.GREEN).apply { setPadding(dp(8), dp(4), dp(8), dp(4)); setOnClickListener { copy(x.t) } })
        row.addView(label("✖", 13f, C.RED).apply { setPadding(dp(8), dp(4), dp(8), dp(4)); setOnClickListener { results.remove(x); render() } })
        box.addView(row); box.addView(label(x.t, 15f))
        return box
    }

    private fun copy(t: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("t", t))
        toast(getString(R.string.copied))
    }

    // ---------- Language picker (only downloaded languages) ----------
    private fun chooseLanguages() {
        menu.visibility = View.GONE
        Models.downloaded { set ->
            val codes = set.toList().sortedBy { langName(it) }
            if (codes.size < 2) { toast(getString(R.string.no_languages)); return@downloaded }
            pick(getString(R.string.from_lang), codes) { s ->
                pick(getString(R.string.to_lang), codes.filter { it != s }) { t ->
                    Prefs.save(this, s, t); toast("${langName(s)} → ${langName(t)}")
                }
            }
        }
    }

    private fun pick(title: String, codes: List<String>, onPick: (String) -> Unit) {
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
        val d = AlertDialog.Builder(ctx).setTitle(title)
            .setItems(codes.map { langName(it) }.toTypedArray()) { _, i -> onPick(codes[i]) }.create()
        d.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        d.show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        closeSel(); hidePanel()
        try { wm.removeView(bubbleRoot) } catch (e: Exception) {}
        vd?.release(); reader?.close(); proj?.stop()
        super.onDestroy()
    }
}
