package com.hanif.translator

import android.app.AlertDialog
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.google.mlkit.nl.translate.TranslateLanguage

class LanguagesActivity : ComponentActivity() {
    private var mine = true
    private var have = setOf<String>()
    private var shown = listOf<String>()
    private val all = TranslateLanguage.getAllLanguages().sortedBy { langName(it) }
    private lateinit var lv: ListView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        val tabs = LinearLayout(this)
        tabs.addView(button(getString(R.string.tab_mine), C.GREEN) { mine = true; refresh() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) })
        tabs.addView(button(getString(R.string.tab_add), C.GRAY) { mine = false; refresh() }, LinearLayout.LayoutParams(0, WRAP, 1f))
        lv = ListView(this).apply { divider = ColorDrawable(C.GRAY); dividerHeight = 1 }
        lv.setOnItemClickListener { _, _, i, _ -> tap(shown[i]) }
        root.addView(tabs); root.addM(lv)
        setContentView(root); root.applyInsets()
        refresh()
    }

    private fun refresh() = Models.downloaded { s ->
        have = s
        shown = all.filter { (it in have) == mine }
        val rows = shown.map { "${langName(it)}  ·  $it  ·  ~45 MB" + if (it in CORE) "  ★" else "" }
        lv.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, rows) {
            override fun getView(p: Int, v: View?, g: ViewGroup): View =
                (super.getView(p, v, g) as TextView).apply { setTextColor(C.FG) }
        }
    }

    private fun tap(c: String) {
        if (c in have) {
            AlertDialog.Builder(this).setMessage("${langName(c)}\n${getString(R.string.delete_q)}")
                .setPositiveButton(R.string.ok) { _, _ -> Models.delete(c) { refresh() } }
                .setNegativeButton(R.string.cancel, null).show()
        } else {
            Toast.makeText(this, R.string.downloading, Toast.LENGTH_SHORT).show()
            Models.download(c) { ok ->
                Toast.makeText(this, if (ok) R.string.done else R.string.failed, Toast.LENGTH_SHORT).show(); refresh()
            }
        }
    }
}
